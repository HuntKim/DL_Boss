# .bashrc

# Source global definitions
if [ -f /etc/bashrc ]; then
	. /etc/bashrc
fi

# Uncomment the following line if you don't like systemctl's auto-paging feature:
# export SYSTEMD_PAGER=

# User specific aliases and functions

alias tomcat='cd /app/weditor/hancom/tomcat/bin'
alias web='cd /app/weditor/hancom/webhwpctrl/webhwp-filter-service'
alias mob='cd /app/mobile/weditor/hancom/mobile/bin'
