#!/bin/bash -v

# War, SDK Update Script .

print_message_and_exit() {  
    printf "$@"" : Failed\n"
    exit 1                  
}  
CURRENT_DIR=$PWD
CURRENT_ACCOUNT=$(id -un)
TOMCAT_ACCOUNT=$CURRENT_ACCOUNT

MANAGER_CONF_DIR=/home/${CURRENT_ACCOUNT}/.webhwpctrl/conf

TOMCAT_ACCOUNT=$(sed -n 's/TOMCAT_ACCOUNT=//p' $MANAGER_CONF_DIR/manager.properties)
DAEMON_DIR=$(sed -n 's/TARGET_DIR=//p' $MANAGER_CONF_DIR/manager.properties)
echo Tomcat Account : $TOMCAT_ACCOUNT
echo Daemon Directory : $DAEMON_DIR

if [ ! -n "$TOMCAT_ACCOUNT" ] || [ ! -n "$DAEMON_DIR" ]; then
    print_message_and_exit 'manager.properties Error'
fi

CONF_DIR=/home/${TOMCAT_ACCOUNT}/.webhwpctrl/conf

WEBAPP=true
DAEMON=true
# t : TargetFilePath
# w : War Files(filterserver, webhwpctrl)
# d: Daemon(daemon, hwpsdk)
while getopts "t:w:d:" option
do
  case "${option}"
  in
    t) TARGET_ZIP_FILE=${OPTARG};;
    w) WEBAPP=${OPTARG};;
    d) DAEMON=${OPTARG};;
  esac
done

if [ ! -n "$TARGET_ZIP_FILE" ]; then
    print_message_and_exit 'Invalid Path'
fi

TARGET_ZIP_FILE=$(readlink -e $TARGET_ZIP_FILE)
echo ${TARGET_ZIP_FILE}  
TARGET_FOLDER=${TARGET_ZIP_FILE:0:${#TARGET_ZIP_FILE} -4}
echo ${TARGET_FOLDER}  
             
if [ -d ${TARGET_FOLDER} ]; then
		INDEX=1
		OLD_TARGET_FOLDER=${TARGET_FOLDER}_${INDEX}
		echo $OLD_TARGET_FOLDER
		while [ -d ${OLD_TARGET_FOLDER} ]
		do
			INDEX=$(($INDEX+1))
			OLD_TARGET_FOLDER=${TARGET_DIR}_${INDEX}
		done
		mv $TARGET_FOLDER $OLD_TARGET_FOLDER
	fi
unzip $TARGET_ZIP_FILE -d $TARGET_FOLDER

cd $TARGET_FOLDER
echo Webapp Update : $DAEMON
if [ $WEBAPP = "true" ]; then
    cp filterserver.war $CATALINA_HOME/webapps
    cp webhwpctrl.war $CATALINA_HOME/webapps
fi

cd script
echo Daemon, SDK Update : $DAEMON
if [ $DAEMON = "true" ]; then
    ./install.sh -t $DAEMON_DIR -a $TOMCAT_ACCOUNT
fi

cd $CURRENT_DIR