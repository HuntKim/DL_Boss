#!/bin/bash

print_message_and_exit() {  
    printf "$@"" : Failed\n"
    exit 1                  
}  

CURRENT_DIR=$PWD
CURRENT_ACCOUNT=$(id -un)
MANAGER_CONF_DIR=/home/${CURRENT_ACCOUNT}/.webhwpctrl/conf

TARGET_DIR=$(sed -n 's/TARGET_DIR=//p' $MANAGER_CONF_DIR/manager.properties)
echo Target Directory : $TARGET_DIR

if [ ! -n "$TARGET_DIR" ]; then
    print_message_and_exit 'manager.properties Error'
fi

# Tomcat Restart
$CATALINA_HOME/bin/shutdown.sh
sleep 20
$CATALINA_HOME/bin/startup.sh

echo $TARGET_DIR
cd ${TARGET_DIR}/webhwp-filter-service
echo `pwd`
# Daemon Restart
${TARGET_DIR}/webhwp-filter-service/shutdown.sh
sleep 20
${TARGET_DIR}/webhwp-filter-service/startup.sh

cd $CURRENT_DIR



