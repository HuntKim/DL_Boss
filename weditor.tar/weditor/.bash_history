ll
./startup.sh
tom
ll
./startup.sh
ll
./shutdown.sh
han
./shutdown.sh
exit
tom
ll
han
ll
./startup.sh
han
ll
tom
ll
./startup.sh
yum lost ImageMagick-c++
yum list ImageMagick-c++
yum list cairo
yum list harfbuzz
yum -y install ImageMagick-c++.x86_64
su -
uname -a
cd /app
ll
han
ll
./shutdown.sh
tom
./shutdown.sh
cd /app
ll
cd
ll
cd -
ll
mv weditor weditor_지자체
mv weditor_DAPA weditor
han
ll
./startup.sh
ps -ef | grep weditor
ll
./shutdown.sh
vi startup.sh
cd
ll
cd
ll
alias ll='ls -al'
alias l='ls -altr'
ll
pwd
cd ..
ll
cd
ll
cd /home/weditor/
ll
cp .* /app/weditor
cp -r .* /app/weditor
ll
cd
ll
cd ons
ll
cd ../rhel7-repo
ll
cd ..
ll
pwd
ll
cd ons
ll
cd ..
ll
rm -fr ons rhel7-repo
ll
pwd
han
ll
./shutdown.sh
./startup.sh
tom
ll
./startup.sh
ll
cd ..
ll
cd logs/
ll
tail -100f filterserver.out
han
ll
./shutdown.sh
tom
ll
./shutdown.sh
han
ll
./startup.sh
tom
./startup.sh
cd ../logs/
ll
l
tail -100f filterserver.out
han
ll
cd logs/
ll
tail -500f filter-service.log
ll
vi filter-service.log
cd /app/weditor/hancom/webhwpctrl/HwpSdk/Bin/
ll
han
ll
./shutdown.sh
tom
ll
./shutdown.sh
han
./startup.sh
tom
startup.sh
./startup.sh
han
ll
./startup.sh
tom
./startup.sh
ls -rlt
cd /app
ls -rlt
cd weditor
ls -rlt
pwd
han'
han
ls -rlt
pwd
cd /app
ll
cd /usr
ll
cd java/
ll
cd jdk1.8.0_321-amd64/bin
ll
pwd
cd /app
ll
/usr/java/jdk1.8.0_321-amd64/bin/jar cvf weditor_KDIC.jar weditor_KDIC
ll
mv weditor weditor_지자체
cd weditor_KDIC
ll
cd ..
ll
mv weditor_KDIC weditor
han
ll
exit
ll
cd /app
ll
rm -fr weditor.tar
han
ll
./startup.sh
tom
ll
./startup.sh
ls
ha
alias
han
ls
tom
ls
cd ..
cd logs
ls
tail -f filterserver.out
cd  /WORK_TEMP/docconv/44cf75f9-b8ad-4420-ae2d-c03e936f21ef
cd /WORK_TEMP
ls
cd /WORK_TEMP
ls
cd docconv
ls
ls -al
cd /
ls
cd /WORK_TEMP
ls
ls -al
ls
cd /
ls
cd /WORK_TEMP
ls
cd ..
ls -al WORK_TEMP
ls
ls -al
exit
ll
han
ll
./shutdown.sh
tom
./shutdown.sh
exit
tom
cd ..
ls
cd logs
ls
ls -altr
tail -f filterserver.out
han
ll
./startup.sh
tom
./startup.sh
ll
cd .webhwpctrl
ll
cd license/
ll
sftp -P 22 weditor@192.168.0.131
pwd
ll
jar xvf weditor.jar
ll
cd weditor
ll
ls -al
. .bash_profile
han
ll
chmod +x *.sh
ll
./startup.sh
tom
ll
chmod +x *.sh
./startup.sh
ps -e | grep weditor
ps -ef | grep weditor
ifconfig -a
ll
cd ..
l
cd ..
ll
cd ..
cd /app
ll
rm -fr weditor.jar 
ll
cd weditor
ll
rm -fr .webhwpctrl .hnc hancom
ll
rm -fr META-INF 
ll
cd .config
ll
cd ..
ll
vi .bash_profile
cd ..
ll
exit
sudo su -
exit
sudo su -
mkdir -p /app/weditor/hancom
mkdir -p /app/weditor/hancom/tomcat
mkdir -p /app/weditor/doc_data
mkdir -p /app/weditor/doc_data/upload
mkdir -p /app/weditor/doc_data/temp
cd /tmp
ll
cd weditor/
ll
unzip apache-tomcat-8.5.57.zip 
cd apache-tomcat-8.5.57
mv * /app/weditor/hancom/tomcat/
cd ..
ll
unzip webhwpctrl-package-onnara-2143.zip 
ll
cd ..
ll
cd weditor/
ll
unzip webhwpctrl-package-onnara-2143.zip 
ll
unzip webhwpctrl-package-onnara-2143.zip 
ll
unzip webhwpctrl-package-onnara-2143.zip 
ll
make install
ll
make configure
make license
ll
mv filterserver.war /app/weditor/hancom/tomcat/webapps/
mv webhwpctrl.war /app/weditor/hancom/tomcat/webapps/ROOT.war
cat /etc/passwd
vi /app/weditor/.webhwpctrl/conf/config.properties 
vi /app/weditor/.webhwpctrl/conf/server.properties 
cd /app/weditor/
ll
cd hancom/
ll
cd tomcat/
ll
cd bin
chmod +x *.sh
cd ..
cd webapps/
rm -rf ROOT docs/
cd ..
cd bin
./startup.sh 
cd ..
cd webhwpctrl/webhwp-filter-service/
./startup.sh 
./shutdown.sh 
./startup.sh 
ll
cat version.txt 
cd ..
cd tomcat/bin
./shutdown.sh 
./startup.sh 
ps -ef|grep tomcat
cd ..
cd webhwpctrl/webhwp-filter-service/
./shutdown.sh 
./startup.sh 
exit
cd /app/weditor/
cd hancom/tomcat/
cd bin
./shutdown.sh 
cd ...
cd ..
cd .
cd ..
ll
cd webhwpctrl/webhwp-filter-service/
ll
./shutdown.sh 
pwd
exit
cd /
cd app
ls -lart
ps -ef | grep java
cd we
ls
cd w
cd weditor/
ls -lart
cd hancom/
ls
cd tomcat/
ls -lart
cd bin
ls- lart
ls -lart
vi startup.sh
vi catalina.sh
cd ~
ls -lart
vi .bash_profile
echo $JAVA_HOME
echo JAVA_HOME
ls -lart
exit
cd /app/weditor/hancom/
ll
cd tomcat/
ll
cd bin
pwd
./startup.sh 
cd ..
ll
cd ..
ll
cd webhwpctrl/
cd webhwp-filter-service/
./startup.sh 
cd /WORK_TEMP/
mkdir -p docconv
ll
clear
ps -ef|grep tomcat
ps -ef|grep hwp
ll
cd ..
clear
rpm -qa|grep crytop
rpm -qa|grep crytop*
yum  list|grep cryptop*
clear
cat /home/weditor/.webhwpctrl/conf/config.properties 
cat /home/weditor/.webhwpctrl/conf/server.properties 
clear
ls /home/weditor/.webhwpctrl/license/
cd /app/weditor/
ll
cd hancom/
ll
clear
pwd
ll
exit
version
webhwp version
webhwpctl version
webhwpctl -version
webhwpctl -v
./webhwpctl -v
ls -al
cd .hnc
ll
cd ..
ll
cd .webhwpctrl/
ll
cd conf/
ll
cd ..
ll
cd license/
ll
cd ..
ll
cd ..
ll
cd ..
ll
cd /app/weditor/
ll
cd hancom/
ll
cd webhwpctrl/
ll
cd webhwp-filter-service/
ll
cd conf
ll
vi server.properties 
vi config.properties 
cd ..
ll
cd lib
ll
cd ..
ll
cat version.txt
pwd
ps -ef | grep hwp
exit
han
ll
./shutdown.sh
tom
./shutdown.sh
ll
exit
cd /
ls- lart
cd app
ls
cd weditor
ls -lart
cd hancom
ls
ls -lart
cd tomcat
ls -lrat
cd logs
ls
tail -f filterserver.log
vi filterserver.log
vi webhwpctrl.log
ls -lart
vi catalina.out
pwd
ls -lart
vi filterserver.log
vi catalina.out
tail -f filterserver.log
pwd
ps -ef  | grep hancom
ls -lart
vi catalina.out
history
su - jboss
exit
cd /
cd app
ls -lart
cd weditor/
ls
ps -ef | grep hancom
ps -ef | grep weditor
cd /
cd app
cd hancom
cd weditor/
ls -lart
cd hancom
ls
cd webhwpctrl/
ls
cd webhwp-filter-service/
ls
cd logs
ls -lart
vi filter-service-19502.log
tail -f filter-service.log
ls
vi .bash_profile
ls
tom
ll
./startup.sh
cd ..
ll
cd ..
ll
cd webhwpctrl/
ll
cd webhwp-filter-service/
ll
./startup.sh
ps -ef | grep hwp
cd /var/log
ll
cd /usr/local/apache2/
ll
cd logs
ll
pwd
cd /
ll
cd /ISO/
ll
cp mobile.zip /app/
chown weditor.user /app/mobile.zip
cd /app
ll
unzip mobile.zip 
ll -rt
cd /WORK_TEMP/ssto
cd /WORK_TEMP/sto
ll
cd /app/
ll
cd mobile
ll
cd weditor/
ll
chmod +x *.sh
ll
cd hancom/
ll
cd mobile/tomcat/
ll
cd webapps/
ll
cd /app/mobile
ll
cd weditor/
ll
cd hancom/
ll
cd mobile/
ll
cd bin/
ll
chmod +x *.sh
./startup.sh 
ll
cd ..
ll
cd tomcat/
ll
cd webapps/
ll
cd ../..
ll
cd ..
ll
cd tomcat/
ll
cd bin/
ll
chmod +x *.sh
cd ../..
ll
cd mobile/bin/
ll
./startup.sh 
ps -ef |grep mobile
./shutdown.sh 
ps -ef |grep mobile
ll -rt
crontab -l
cd /app/mobile
ll
cd weditor/hancom/
ll
cd mobile/
ll
vi /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props/org.properties
cd /app/mobile
cd weditor/hancom/
ll
cd mobile/
ll
cd bin/
ll
./startup.sh 
ps -ef |grep mobile
netstat -antp |grep LISTEN
clear
crontab -l
ps -ef |grep mobile
cd /app/mobile
ll
cd weditor/
ll
vi /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props/org.properties
ll
cp webhwp_tempDel.sh /app/weditor
cd /app/weditor/
ll
vi webhwp_tempDel.sh 
ll -rt
vi ~/.bash_profile 
ll -rt
mobDsTailLog
clear
cd /
ll
netstat -antp |grep LISTEN
clear
cd /
cd app
cd we
cd weditor/
cd hancom/
cd webhwpctrl/
cd webhwp-filter-service/
cd logs
ls -lart
vi filter-service.log
cd ..
cd hancom
ls-lart
cd ..
cd tomcat/
ls
cd logs
ls -lart
vi catalina.out
vi webhwpctrl.log
exit
ll
han
ll
./shutdown.sh
tom
ll
./shutdown.sh
ps -ef | grep weditor
cd /app/mobile/weditor/hancom/tomcat
ll
cd bin
ll
pwd
tom
pwd
cd -
ll
./shutdown.sh
ps -ef | grep weditor
ll
cd ..
ll
cd ..
ll
pwd
cd webhwpctrl/
ll
cd ..
exit
vi ~/.bash_profile 
cd /app/weditor/doc_data/
ll -rt
clear
cd /app/weditor/hancom/webhwpctrl/webhwp-filter-service/
ll
mkdir err_logs
mv *log err_logs/
ll
./shutdown.sh 
cd ../../tomcat/bin/
./shutdown.sh 
cd /app/weditor/doc_data/
ll
mv temp/ tmp
vi /home/weditor/.webhwpctrl/conf/config.properties 
tomcat
./startup.sh 
web
./startup.sh 
clear
cd /app/weditor/doc_data/
ll -rt
clear
ll -rt
curl localhost:8680
ll -rt
cd /app/
ll
cd mobile
ll
cd weditor/
ll
cd hancom/
ll
cd mobile/
ll
cd tomcat/
ll
cd webapps/
ll
cd ..
ll -rt
cd /
cd tomcat
cd app
cd weditor/
ls
ls -lart
cd hancom
ls -lart
cd tomcat
ls -lart
cd bin
ls -lart
./shutdown.sh
cd ..
cd webhwpctrl/
cd webhwp-filter-service/
ls -lart
./shutdown.sh
ps -ef | grep hancom
ps -ef | grep tomcat
netstat -anp | grep LISTEN | grep 8680
netstat -an | grep 8680
netstat -a | grep 8680
ls
ls -trl
cd
ls
ls -al
vi .bashrc
source .bashrc
vi /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props
cd /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props
ls
vi org.properties 
web
./shutdown.sh 
tom
./shutdown.sh 
mob
ls
tom
ls
./startup.sh 
web
ls
./startup.sh 
mob
ls
./shutdown.sh 
./startup.sh 
pwd
history
cd /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props
ls
ls -al
vi org.properties 
ls
mob
ls
./shutdown.sh 
./startup.sh 
ip a
history
cd /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props
ls
vi org.properties 
mob
./shutdown.sh 
cd -
ls
vi .or
vi org.properties 
mob
./shutdown.sh 
./startup.sh 
exit
vi .bash_profile 
exit
mkdir test
ls -lart
rm -rf test
exit
habn
han
./shutdown.sh 
./startup.sh 
./shutdown.sh 
./startup.sh 
tom
./shutdown.sh 
./startup.sh 
cd /app/was
ls -lart
cd ..
cd mobile/
ls -alrt
cd weditor/
ls -lart
cd hancom/tomcat/
ls -alrt
cd bin/
./shutdown.sh 
./startup.sh 
ls
vi .bash_profile
. ./.bash_profile
touch aaa
ls
ls -al
vi .bash_profile
. ./.bash_profile
ls -altr
touch bbb
ls
ls -al
rm -f aaa bbb
ls
ls -altr
ls
vi .bash_profile
exit
ls
touch aaa
ls
rm -f aaa
touch aaa
ls -al
ls
han
ls
web
./shutdown.sh 
./startup.sh 
tom
./shutdown.sh 
./startup.sh 
ls
vi .bash_profile
exit
ls
han
ls
./shutdown.sh
./startup.sh
tom
ls
./shutdown.sh
./startup.sh
vi .bash_profile 
exit
tom
./shutdown.sh 
./startup.sh 
web
./shutdown.sh 
./startup.sh 
cd /tmp
ls
unzip apache-tomcat-8.5.87.zip 
ll
tomcat
ls
./shutdown.sh 
ls
cd ..
ls
tar cvf tomcat_20230417.tar ./*
cd /tmp/apache-tomcat-8.5.87
ls
cp -rp ./* /app/weditor/hancom/tomcat/
tomcat
chmod +x *.sh
./startup.sh 
cat .bash_profile | grep umask
ll /WORK_TEMP/docconv
mkdir /WORK_TEMP/docconv
ll /WORK_TEMP/docconv
ll /WORK_TEMP/
exit
crontab -l
exit
cd /WORK_TEMP/
ls -al
mkdir docconv
ls -al
exit
cd /WORK_TEMP/
ll
mkdir docconv
ll
cd 
cd cd 
cd /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/cd 
cd 
cd /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props/
l
vi org.properties 
exit
cd /WORK_TEMP/
ls -al
mkdir docconv
ls -al
history
exit
crontab -l
exit
cd /WORK
cd /WORK_TEMP/
ls -a;
ls -al
cd /WORK_TEMP/
ls -al
cd /WORK_TEMP/
ls -al
cd /WORK_TEMP/
ls -al
cd /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props/
ll
vi org.properties 
exit
vi /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props/org.properties
ll
pwd
alias ll='ls -al'
alias l='ls -altr'
ll
pwd
   cd ..
ll
cd weditor
ll
du -h
cd ..
ll
cd -
ll
cd .webhwpctrl
ll
cd license/
ll
cd ../../../
ll
tarar cvf weditor.tar weditor
tar cvf weditor.tar weditor
exit
