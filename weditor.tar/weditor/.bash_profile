# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
	. ~/.bashrc
fi

# User specific environment and startup programs
PATH=$PATH:/app/weditor/hancom/tomcat/bin:/app/weditor/hancom/webhwpctrl/webhwp-filter-service:$HOME/.local/bin:$HOME/bin:$JAVA_HOME/bin

umask 002

alias han='cd /app/weditor/hancom/webhwpctrl/webhwp-filter-service'
alias tom='cd /app/weditor/hancom/tomcat/bin'
alias ll='ls -al'
alias l='ls -altr'

export PATH

export TOMCAT_HOME_MOB_DS=' /app/mobile/weditor/hancom/mobile'
export CONFIG_PATH=' /app/mobile/weditor/hancom/mobile/tomcat/webapps/ROOT/WEB-INF/classes/onnaraDs/props'
alias mobDsCd='cd $TOMCAT_HOME_MOB_DS/tomcat'
alias mobDsCdLog='cd $TOMCAT_HOME_MOB_DS/tomcat/logs'
alias mobDsUp='$TOMCAT_HOME_MOB_DS/bin/startup.sh'
alias mobDsDown='$TOMCAT_HOME_MOB_DS/bin/shutdown.sh'
alias mobDsViewGlb='vi $CONFIG_PATH/globals.properties'
alias mobDsViewOrg='vi CONFIG_PATH/org.properties'
alias mobDsTailLog='tail -f $TOMCAT_HOME_MOB_DS/tomcat/logs/catalina.out'


printf "################################################\n"
printf "HANCOM DOC SERVER - $(hostname -I)\n"
printf "모바일결재서버 2.0 관련 \n"
printf "\- mobDsCd:\t Tomcat 경로로 이동\n"
printf "\- mobDsCdLog:\t Tomcat 로그로 이동\n"
printf "\- mobDsUp:\t Tomcat 기동\n"
printf "\- mobDsDown:\t Tomcat 중지\n"
printf "\- mobDsViewGlb:\t 전역 환경설정파일 조회\n"
printf "\- mobDsViewOrg:\t 기관 환경설정파일 조회\n"
printf "\- mobDsTailLog:\t  Tomcat 로그 실시간 출력\n"
printf "################################################\n\n\n"
